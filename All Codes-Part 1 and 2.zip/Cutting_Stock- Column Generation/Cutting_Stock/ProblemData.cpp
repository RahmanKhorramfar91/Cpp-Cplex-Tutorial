#include"ProblemData.h"

int ProblemData::LL = 40;
int ProblemData::nL = 6;
int* ProblemData::ReqL= new int[nL] { 4, 2, 6, 7, 8, 12 };
int* ProblemData::b = new int[nL] {20, 41, 23, 12, 9, 34};
