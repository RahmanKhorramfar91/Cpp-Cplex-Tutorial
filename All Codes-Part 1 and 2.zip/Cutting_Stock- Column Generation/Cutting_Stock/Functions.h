#pragma once
#include"ProblemData.h"
double SubProblem(double* Dual_Vals, int* NewPattern); // a knapsack problem